__author__ = 'mariolukas'
import os
import json
import shutil
from collections import namedtuple
from fabscan.FSConfig import Config

def isRaspberryPi():
    if os.uname()[4].startswith("arm"):
        return True
    else:
        return False

def _json_object_hook(d):
    return namedtuple('X', d.keys())(*d.values())

def json2obj(data):
    return json.loads(data, object_hook=_json_object_hook)

def new_message():
        message = dict()
        message['type'] = ""
        message['data'] = dict()

        return message

def delete_scan(dir_name,ignore_errors=True):
    basedir = os.path.dirname(__file__)
    #basedir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    folder =  basedir+Config.instance().folders.scans+dir_name+"/"

    if os.path.isdir(folder):
        shutil.rmtree(folder, ignore_errors=True)
    else:
        print "no folder"

